const f=require('./superfunz');

test('test 1',()=>
{
    expcect(f.offusca('ciao')).toBe('CI4O');
    expcect(f.offusca('ciaob')).toBe('CI4O8');
})

