function sum(a, b) {
    return a + b;
  }
  module.exports = sum; //rende disponibile la funzione ad altri moduli