// sostituire carattere A->4; B->8


function offusca(s)
{
    s1=s.toUpperCase(s);
    s1=s1.replace('A',4);
    s1=s1.replace('B',8);
    return s1;
}

console.log("Esecuzione del programma");
console.log(offusca("ciaob"));

module.exports={offusca};
