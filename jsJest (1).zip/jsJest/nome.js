function aggettivo(nome)
{
    if(nome=='Cristiano')
    {
        return 'Ronaldo';
    }

    if(nome=='Lionel')
    {
        return 'a';
    }
}

module.exports=aggettivo;