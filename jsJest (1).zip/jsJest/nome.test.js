const aggettivo = require('./nome');

test('Lionel -> Messi', () => {
    expect(aggettivo('Lionel')).toBe('Messi');
  });

test('Cristiano -> Ronaldo', () => {
    expect(aggettivo('Cristiano')).toBe('Ronaldo');
  });